
    <?php 
        $title = 'Main Page';
        require_once 'includes/header.php'; ?>

            <br><br><br><br>
        <div style = "margin: auto" class="position-absolute top-10 start-50 translate-middle-x row">

            <!-- <button type="button" class="btn btn-secondary btn-lg">Large button</button>
            <button type="button" class="btn btn-secondary btn-lg">Large button</button> -->

            <div class="card" style="width: 17rem;">
                <br>
                <img src="Gambar/admin.png" class="card-img-top" alt="admin" style = "height:100%">
                <div class="card-body">
                    <a href="mainAdmin.php" class="btn btn-primary" style = "width:100%">Administrator</a>
                </div>
            </div>
            
            <div class="card" style="width: 17rem;">
                <br>
                <img src="Gambar/customer.png" class="card-img-top" alt="customer">
                <div class="card-body">
                    <a href="customer.php" class="btn btn-primary" style = "width:100%">Customer</a>
                </div>
            </div>
            
        </div>



<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    <?php require_once 'includes/footer.php'; ?>



