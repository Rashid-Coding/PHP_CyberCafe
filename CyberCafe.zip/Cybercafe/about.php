
<?php 
    $title = 'About';
    require_once 'includes/header.php';

?>
<br><br>
<div class="position-absolute top-10 start-50 translate-middle-x"><h1><u>Meet Our Team</u></h1>

</div>
<br><br>

<div class="row">

      <div class="column">
        <div class="card">
          <img src="Gambar/ABDUL RASHID BIN NUHAIRI 1911767.jpg" alt="RASHID" style="width:100%">
          <div class="container">
            <h6>ABDUL RASHID BIN NUHAIRI</h6>
            <p>1911767</p>
          </div>
        </div>
      </div>

      <div class="column">
        <div class="card">
          <img src="Gambar/Ikram.jpg" alt="IKRAM" style="width:100%">
          <div class="container">
            <h6>MUHAMMAD IKRAM BIN IQBAL FITHRI</h6>
            <p>1912071</p>
          </div>
        </div>
      </div>

      <div class="column">
        <div class="card">
          <img src="Gambar/Aizat.jpg" alt="AIZAT" style="width:100%">
          <div class="container">
            <h6>MUHAMMAD ADHWA AIZAT BIN HARUN</h6>
            <p>1911549</p>
          </div>
        </div>
      </div>

      <div class="column">
        <div class="card">
          <img src="Gambar/Amer.jpg" alt="AS" style="width:100%">
          <div class="container">
            <h6>MUHAMMAD AMER SYAFIQ BIN SANUSI</h6>
            <p>1914119</p>
          </div>
        </div>
      </div>
</div>


<?php require_once 'includes/footer.php'; ?>
